from game.scenes.Scene import Scene
from game.scenes.MenuScene import MenuScene
from game.scenes.OverScene import OverScene
from game.scenes.PlayingScene import PlayingScene
from game.scenes.ScoreScene import ScoreScene