from game.bricks.Brick import Brick
from game.bricks.LifeBrick import LifeBrick
from game.bricks.BoostBrick import BoostBrick