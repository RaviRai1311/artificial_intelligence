<html>
<head>
    <link rel="stylesheet" type="text/css" href="table.css"/>
</head>
<?php
require('./scores.php');
?>
</html>